Deprecations
============

.. include:: pending-removal-in-3.13.rst

.. include:: pending-removal-in-3.14.rst

.. include:: pending-removal-in-3.15.rst

.. include:: pending-removal-in-3.16.rst

.. include:: pending-removal-in-future.rst

C API Deprecations
------------------

.. include:: c-api-pending-removal-in-3.14.rst

.. include:: c-api-pending-removal-in-3.15.rst

.. include:: c-api-pending-removal-in-future.rst
