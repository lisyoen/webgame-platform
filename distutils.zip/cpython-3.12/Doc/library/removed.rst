:tocdepth: 1

.. _removed:

***************
Removed Modules
***************

The modules described in this chapter have been removed from the Python
standard library.  They are documented here to help people find replacements.


.. toctree::
   :maxdepth: 1

   asynchat.rst
   asyncore.rst
   distutils.rst
   imp.rst
   smtpd.rst
